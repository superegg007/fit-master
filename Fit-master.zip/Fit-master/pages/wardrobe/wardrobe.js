// //index.js
// Page({
//   data: {
//     text: "This is page data."
//   },
//   onLoad: function(options) {
//     // 页面创建时执行
//   },
//   onShow: function() {
//     // 页面出现在前台时执行
//   },
//   onReady: function() {
//     // 页面首次渲染完毕时执行
//   },
//   onHide: function() {
//     // 页面从前台变为后台时执行
//   },
//   onUnload: function() {
//     // 页面销毁时执行
//   },
//   onPullDownRefresh: function() {
//     // 触发下拉刷新时执行
//   },
//   onReachBottom: function() {
//     // 页面触底时执行
//   },
//   onShareAppMessage: function () {
//     // 页面被用户分享时执行
//   },
//   onPageScroll: function() {
//     // 页面滚动时执行
//   },
//   onResize: function() {
//     // 页面尺寸变化时执行
//   },
//   onTabItemTap(item) {
//     // tab 点击时执行
//     console.log(item.index)
//     console.log(item.pagePath)
//     console.log(item.text)
//   },
//   // 事件响应函数
//   viewTap: function() {
//     this.setData({
//       text: 'Set some data for updating view.'
//     }, function() {
//       // this is setData callback
//     })
//   },
//   // 自由数据
//   customData: {
//     hi: 'MINA'
//   }
// })
import Ajax from './../../utils/request'
const app = getApp()

Page({
  data: {
    hasUserInfo: false,
    current_class: 'tab1',
    current_clothes: 'tab1',
    current_suits: 'tab1',
    addhidden:'hidden',
    shangyi: [{
           pic_url: 'http://blog.sherrybaby.club/image/fit/a.png'
         },
         {
           pic_url: 'http://blog.sherrybaby.club/image/fit/b.png'
         },
         {
           pic_url: 'http://blog.sherrybaby.club/image/fit/c.png'
         },
         {
           pic_url: 'http://blog.sherrybaby.club/image/fit/d.png'
         },
         {
           pic_url: 'http://blog.sherrybaby.club/image/fit/a/e.jpg'
         }],
    kuzi: [{
      pic_url: 'http://blog.sherrybaby.club/image/fit/a.png'
    },
      {
        pic_url: 'http://blog.sherrybaby.club/image/fit/b.png'
      },
      {
        pic_url: 'http://blog.sherrybaby.club/image/fit/c.png'
      },
      {
        pic_url: 'http://blog.sherrybaby.club/image/fit/d.png'
      },
      {
        pic_url: 'http://blog.sherrybaby.club/image/fit/a/e.jpg'
      }],
      qunzhuang: [{
      pic_url: 'http://blog.sherrybaby.club/image/fit/a.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/b.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/c.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/d.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/a/e.jpg'
    }],
    xiewa: [{
      pic_url: 'http://blog.sherrybaby.club/image/fit/a.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/b.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/c.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/d.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/a/e.jpg'
    }],
    peishi: [{
      pic_url: 'http://blog.sherrybaby.club/image/fit/a.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/b.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/c.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/d.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/a/e.jpg'
    }],
    baobao: [{
      pic_url: 'http://blog.sherrybaby.club/image/fit/a.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/b.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/c.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/d.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/a/e.jpg'
    }],
    shangwu: [{
      pic_url: 'http://blog.sherrybaby.club/image/fit/a.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/b.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/c.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/d.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/a/e.jpg'
    }],
    xiuxian: [{
      pic_url: 'http://blog.sherrybaby.club/image/fit/a.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/b.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/c.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/d.png'
    },
    {
      pic_url: 'http://blog.sherrybaby.club/image/fit/a/e.jpg'
    }]
    // clothes: {
    //   a: [
    //     {
    //       pic_url: 'http://blog.sherrybaby.club/image/fit/a.png'
    //     },
    //     {
    //       pic_url: 'http://blog.sherrybaby.club/image/fit/b.png'
    //     },
    //     {
    //       pic_url: 'http://blog.sherrybaby.club/image/fit/c.png'
    //     },
    //     {
    //       pic_url: 'http://blog.sherrybaby.club/image/fit/d.png'
    //     },
    //     {
    //       pic_url: 'http://blog.sherrybaby.club/image/fit/a/e.jpg'
    //     }
    //   ],
    //   b: [
    //     {
    //       pic_url: 'http://blog.sherrybaby.club/image/fit/b/a.jpeg'
    //     },
    //     {
    //       pic_url: 'http://blog.sherrybaby.club/image/fit/b/b.jpeg'
    //     },
    //     {
    //       pic_url: 'http://blog.sherrybaby.club/image/fit/b/c.jpeg'
    //     },
    //     {
    //       pic_url: 'http://blog.sherrybaby.club/image/fit/b/d.jpeg'
    //     }
    //   ],
    //   c: [

    //   ],
    //   d: [

    //   ],
    //   e: [

    //   ],
    //   f: [

    //   ],
    // }
  },
  onLoad: function () {
    if (app.globalData.hasUserInfo) {
      this.setData({
        hasUserInfo: true
      })
    }
    //获得用户token
    var token=wx.getStorageSync('token');
    //得到上衣部分数据
    var that = this;
    wx.request({
      url: 'https://ssl.lyzwhh.top/clothes/clothes/like',
      method:'POST',
      header:{
        'Content-Type':'application/json',
        token
      },
      data:{
        "word": "上衣"
      },
      success(res){
        let shangyi=that.data.shangyi;
        that.setData({shangyi:res.data.data.data});
        console.log("上衣")
        console.log(that.data.shangyi)
      },
      complete(res){}
    }),
      //得到裤子部分数据
      wx.request({
        url: 'https://ssl.lyzwhh.top/clothes/clothes/like',
        method: 'POST',
        header: {
          'Content-Type': 'application/json',
          token
        },
        data: {
          "word": "裤子"
        },
        success(res) {
          let kuzi = that.data.kuzi
          that.setData({
            kuzi: res.data.data.data,
          })
          console.log('裤子'+that.data.kuzi)
        },
        complete(res) { }
      }),
      //得到裙装部分数据
      wx.request({
        url: 'https://ssl.lyzwhh.top/clothes/clothes/like',
        method: 'POST',
        header: {
          'Content-Type': 'application/json',
          token
        },
        data: {
          "word": "裙装"
        },
        success(res) {
          let qunzhuang = that.data.qunzhuang
          that.setData({
            qunzhuang: res.data.data.data,
          })
          console.log('裙装'+that.data.qunzhuang)
        },
        complete(res) { }
      }),
      //得到鞋袜部分的数据
      wx.request({
        url: 'https://ssl.lyzwhh.top/clothes/clothes/like',
        method: 'POST',
        header: {
          'Content-Type': 'application/json',
          token
        },
        data: {
          "word": "鞋袜"
        },
        success(res) {
          let xiewa = that.data.xiewa
          that.setData({
            xiewa: res.data.data.data,
          })
          console.log('鞋袜'+that.data.xiewa)
        },
        complete(res) { }
      }),
      //得到配饰部分的数据
      wx.request({
        url: 'https://ssl.lyzwhh.top/clothes/clothes/like',
        method: 'POST',
        header: {
          'Content-Type': 'application/json',
          token
        },
        data: {
          "word": "配饰"
        },
        success(res) {
          let peishi = that.data.peishi
          that.setData({
            peishi: res.data.data.data,
          })
          console.log('配饰'+that.data.peishi)
        },
        complete(res) { }
      }),
      //得到包包部分的数据
      wx.request({
        url: 'https://ssl.lyzwhh.top/clothes/clothes/like',
        method: 'POST',
        header: {
          'Content-Type': 'application/json',
          token
        },
        data: {
          "word": "包包"
        },
        success(res) {
          let baobao = that.data.baobao
          that.setData({
            baobao: res.data.data.data,
          })
          console.log('包包'+that.data.baobao)
        },
        complete(res) { }
      }),    
    //得到商务部分的数据
    wx.request({
      url: 'https://ssl.lyzwhh.top/clothes/suit/like',
      method: 'POST',
      header: {
        'Content-Type': 'application/json',
        token
      },
      data: {
        "word": "商务"
      },
      success(res) {
        let shangwu = that.data.shangwu
        that.setData({
          shangwu: res.data.data.data,
        })
        console.log('商务'+that.data.shangwu)
      },
      complete(res) { }
    }),
    //得到休闲部分的数据
    wx.request({
      url: 'https://ssl.lyzwhh.top/clothes/suit/like',
      method: 'POST',
      header: {
        'Content-Type': 'application/json',
        token
      },
      data: {
        "word": "休闲"
      },
      success(res) {
        let xiuxian = that.data.xiuxian
        that.setData({
          xiuxian: res.data.data.data,
        })
        console.log('休闲'+that.data.xiuxian)
      },
      complete(res) { }
    })
    
  },
  // 页面出现在前台时运行
  // 判断当前用户是否已经登录
  onShow: function () {
    this.data.hasUserInfo === app.globalData.hasUserInfo ?
      null
        :
      this.setData({
        hasUserInfo: app.globalData.hasUserInfo
      })
  },
  // 用户未登录情况下,点击登录
  handleLogin: function () {
    wx.switchTab({
      url: '/pages/mine/mine'
    })    
  },
  // 大类切换
  handleChangeClass: function ({detail}) {
    this.setData({
      current_class: detail.key
    })
  },
  // 衣服切换
  handleChangeClothes: function ({detail}) {
    this.setData({
      current_clothes: detail.key
    })
  },
  // 搭配切换
  handleChangeSuits: function ({detail}) {
    this.setData({
      current_suits: detail.key
    })
  },
  //单品详细页面切换
  gotoclothe:function(options){
    wx.navigateTo({
      url: '/pages/wardrobe/clothe/clothe',
    })
  },
  //加号选项出现
  picchoice:function(options){
      this.setData({
        addhidden:"visible"
      })
  },
  //拍照选取图片
  camerachoice:function(options){
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['camera'], // 可以指定来源是相册还是相机，默认二者都有
      success(res) {
        let tempFilePaths = res.tempFilePaths; // 返回选定照片的本地路径列表
        wx.setStorageSync('clothepicurl', tempFilePaths)
        wx.navigateTo({
          url: '/pages/wardrobe/clothe/clothe',
        })
        console.log(wx.getStorageSync('clothepicurl'))
      },
    })
  },
  //相册选取图片
  collectionchoice:function(options){
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album'], // 可以指定来源是相册还是相机，默认二者都有
      success(res) {
        let tempFilePaths = res.tempFilePaths; // 返回选定照片的本地路径列表
        wx.setStorageSync('clothepicurl', tempFilePaths)
        wx.navigateTo({
          url: '/pages/wardrobe/clothe/clothe',
        })
        console.log(wx.getStorageSync('clothepicurl'))
      },
    })
  }
})