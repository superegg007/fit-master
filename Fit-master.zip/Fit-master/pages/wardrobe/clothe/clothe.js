// pages/wardrobe/clothe/clothe.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    select: false,
    sort_name: '--请选择--',
    sorts: ['上衣', '裤子', '裙装','鞋袜','配饰','包包'],
    clotheinfo: {
      sort: '', 
      pic_url: "urlurl.com",
      category: "",
      brand: "测试",
      color: "1",
      price: "未填写",
      tags: [],
      remarks: "",
      count: 0,
      scene:'',
      season:'',
      style:''}
  },
  //返回按钮-返回衣橱页
  returnwardrobe:function(){
    wx.navigateBack({
      url:'/pages/wardrobe/wardrobe'
    })
  },
  //分类显示选项
  bindShowMsg() {
    this.setData({
      select: !this.data.select
    })
  },
  //分类设置选择
  mySelect(e) {
    console.log(e)
    var name = e.currentTarget.dataset.name
    this.setData({
      sort_name: name,
      select: false
    })
  },
  //得到品牌文本框值
  getbrand: function (brand) {
    console.log(brand.detail.value);
    this.data.clotheinfo.brand = brand.detail.value;
    console.log('brand'+this.data.clotheinfo.brand)
  },
  //获取添加标签单选框值
  tagchange:function(tag){
     console.log(tag.detail.value);
     this.data.clotheinfo.tags = tag.detail.value;
     console.log('tags'+this.data.clotheinfo.tags)
  },
  //得到场景文本框值
  getscene: function (scene) {
    console.log(scene.detail.value);
    this.data.clotheinfo.scene = scene.detail.value;
    console.log('scene'+this.data.clotheinfo.scene)
  },
    //得到风格文本框值
  getstyle: function (style) {
    console.log(style.detail.value);
    this.data.clotheinfo.style = style.detail.value;
    console.log('style'+this.data.clotheinfo.style)
  },
  //得到季节文本框值
  getseason: function (season) {
    console.log(season.detail.value);
    this.data.clotheinfo.season = season.detail.value;
    console.log('season'+this.data.clotheinfo.season)
  },
  //得到备注文本框值
  getremarks: function (remarks) {
    console.log(remarks.detail.value);
    this.data.clotheinfo.remarks = remarks.detail.value;
    console.log('remarks'+this.data.clotheinfo.remarks)
  },
  // clotheok:function(options){
  //   var token = wx.getStorageSync('token')
  //   var that = this;
  //   wx.request({
  //     url: 'https://ssl.lyzwhh.top/clothes/clothes',
  //     method:'POST',
  //     header: {
  //       'Content-Type' : 'application/json',
  //       token
  //     },
  //     data:{
  //       'pic_url':'test'
  //     },
  //   success(res){
  //     wx.showToast({
  //       title: '提交成功',
  //       icon: 'succcess',
  //     })
  //     console.log(res)
  //     wx.navigateBack({
  //       url: 'pages/wardrobe/wardrobe',
  //     })
  //   },
  //   fail(res){
  //     console.log(res)
  //   }
  //   })
  // },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var pic_url = wx.getStorageSync('clothepicurl');
    this.setData({
      'clotheinfo.pic_url':pic_url
    })
    console.log('url:'+this.data.clotheinfo.pic_url)
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})